<?php
$koneksi = mysqli_connect('localhost','root','','iuran_sampah_warga');
?>